var cordenadas_X = [],
    cordenadas_Y = [];
var img = new Image();

if (window.addEventListener) {
    window.addEventListener(
        "load",
        function () {
            var canvas, context;
            var tool;
            this.isOldIE = window.G_vmlCanvasManager;
            var imageLoader = document.getElementById("imageLoader"), 
                cropLoader = document.getElementById("crop");

            function init() {
                canvas = document.getElementById("canvas");
                if (!canvas) {
                    alert("Error: I cannot find the canvas element!");
                    return;
                }

                if (!canvas.getContext) {
                    alert("Error: no canvas.getContext!");
                    return;
                }

                context = canvas.getContext("2d");
                if (!context) {
                    alert("Error: failed to getContext!");
                    return;
                }

                if (this.isOldIE) {
                    G_vmlCanvasManager.initElement(canvas);
                }

                context.lineWidth = 1;
                context.lineJoin = "round";
                context.globalCompositeOperation = "destination-over";

                tool = new tool_line();

                canvas.addEventListener("mousedown", ev_canvas, false);
                canvas.addEventListener("mousemove", ev_canvas, false);
                canvas.addEventListener("mouseup", ev_canvas, false);
                imageLoader.addEventListener("change", Image, false);
                cropLoader.addEventListener("click", click, false);
            }

            function ev_canvas(ev) {
                if (ev.layerX || ev.layerX == 0) {
                    ev._x = ev.layerX;
                    ev._y = ev.layerY;
                } else if (ev.offsetX || ev.offsetX == 0) {
                    ev._x = ev.offsetX;
                    ev._y = ev.offsetY;
                }

                var func = tool[ev.type];
                if (func) {
                    func(ev);
                }
            }

            function Image(ev) {
                var reader = new FileReader();
                reader.onload = function (event) {
                    img.onload = function () {
                        context.drawImage(img, 0, 0);
                    };
                    img.src = event.target.result;
                };
                reader.readAsDataURL(ev.target.files[0]);
            }

            function click() {
                context.clearRect(0, 0, canvas.width, canvas.height);
                context.beginPath();
                context.width = canvas.width;
                context.height = canvas.height;
                context.globalCompositeOperation = "destination-over";

                context.beginPath();
                context.lineJoin = "round";

                var offset_left = canvas.offsetLeft,
                    offset_top = canvas.offsetTop;

                for (var i = 0; i < cordenadas_X.length; i += 1) {
                    var x = parseInt(cordenadas_X[i]);
                    var y = parseInt(cordenadas_Y[i]);

                    if (i == 0) {
                        context.moveTo(x - offset_left, y - offset_top);
                    } else {
                        context.lineTo(x - offset_left, y - offset_top);
                    }
                }

                var pattern = context.createPattern(img, "repeat");
                context.fillStyle = pattern;
                context.fill();

                cordenadas_X.push(canvas.width);
                cordenadas_Y.push(canvas.height);
            }

            function tool_line() {
                var tool = this,
                    count = 0;
                this.started = false;

                this.mousedown = function (ev) {
                    tool.started = true;
                    tool.x0 = ev._x;
                    tool.y0 = ev._y;

                    var start_angle = 0,
                        end_angle = 2 * Math.PI;

                    context.beginPath();
                    context.arc(ev._x, ev._y, 3, start_angle, end_angle);
                    context.fillStyle = "black";
                    context.fill();
                    context.stroke();

                    cordenadas_X.push(ev._x);
                    cordenadas_Y.push(ev._y);
                };

                this.mousemove = function (ev) {
                    if (!tool.started) {
                        return;
                    }

                    if (tool.x0 == ev._x && tool.y0 == ev._y) {
                        //canvas.style.cursor = "pointer";
                    }
                };

                this.mouseup = function (ev) {
                    if (tool.started && count == 0) {
                        tool.mousemove(ev);
                        tool.started = false;

                        context.globalCompositeOperation = "destination-out";
                        context.beginPath();
                        context.moveTo(tool.x0, tool.y0);
                        context.lineTo(ev._x, ev._y);
                        context.strokeStyle = "#ff69b4";
                        context.lineJoin = "round";
                        context.stroke();
                        context.closePath();

                        var start_angle = 0,
                            end_angle = 2 * Math.PI;

                        context.beginPath();
                        context.arc(ev._x, ev._y, 3, start_angle, end_angle);
                        context.fillStyle = "black";
                        context.closePath();
                        context.fill();
                        context.stroke();

                        cordenadas_X[count] = ev._x;
                        cordenadas_Y[count] = ev._y;

                        count = count + 1;
                    } else {
                        context.globalCompositeOperation = "destination-out";
                        context.beginPath();
                        context.moveTo(cordenadas_X[count - 1], cordenadas_Y[count - 1]);
                        context.lineTo(ev._x, ev._y);
                        context.strokeStyle = "#ff69b4";
                        context.lineJoin = "round";
                        context.stroke();
                        context.closePath();

                        var start_angle = 0,
                            end_angle = 2 * Math.PI;

                        context.beginPath();
                        context.arc(ev._x, ev._y, 3, start_angle, end_angle);
                        context.fillStyle = "black";
                        context.closePath();
                        context.fill();
                        context.stroke();

                        count = count + 1;
                    }
                };
            }
            init();
        },
        false
    );
}

function erase() {
    
        canvas = document.getElementById("canvas");
        var ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        img = null;
    
}

function download() {
    var str_text = "";

    for (var i = 0; i < cordenadas_X.length; i++) {
        if (i != cordenadas_X.length - 1) {
            str_text += cordenadas_X[i] + "," + cordenadas_Y[i] + ",";
        } else {
            str_text += cordenadas_X[i] + "," + cordenadas_Y[i];
        }
    }

    var element = document.createElement("a");
    element.setAttribute(
        "href",
        "data:text/plain;charset=utf-8," + encodeURIComponent(str_text)
    );
    element.setAttribute("download", "coordenadas.txt");

    element.style.display = "none";
    document.body.appendChild(element);

    element.click();

    document.body.removeChild(element);
}



var canvas = document.getElementById("canvas"),
    context = canvas.getContext("2d");

function corte() {
    var input = document.getElementById("txtLoader");
    var fReader = new FileReader();
    fReader.readAsText(input.files[0]);

    fReader.onload = function () {
        coordinates = fReader.result;
        drawPolygon(coordinates);
    };
}

function drawPolygon(coordinates) {
    var data = coordinates.split(",").map(Number),
        cordenadas_X = [],
        cordenadas_Y = []
        j = 0,
        scalew = 0,
        scaleh = 0;;

    for (i = 0; i < data.length; i += 2) {
        cordenadas_X[j] = data[i];
        cordenadas_Y[j] = data[i + 1];
        j += 1;
    }
    
    canvasw = cordenadas_X.pop();
    canvash = cordenadas_Y.pop();

    context.clearRect(0, 0, canvas.width, canvas.height);
    context.beginPath();
    context.width = canvas.width;
    context.height = canvas.height;
    context.globalCompositeOperation = "destination-over";

    context.beginPath();
    context.lineJoin = "round";

    var offset_left = canvas.offsetLeft,
        offset_top = canvas.offsetTop;
        console.log(offset_left, offset_top);

    if ((canvasw > canvas.width) && (canvash > canvas.height)){
        scalew = canvasw / canvas.width;
        scaleh = canvash / canvas.height;

        for (var i = 0; i < cordenadas_X.length; i += 1) {
            var x = parseInt(cordenadas_X[i]);
            var y = parseInt(cordenadas_Y[i]);
    
            if (i == 0) {
                context.moveTo((x - offset_left) / scalew, (y - offset_top) / scalew);
            } else {
                context.lineTo((x - offset_left) / scalew, (y - offset_top) / scalew);
            }
        }

    }else {
        scalew = canvas.width / canvasw;
        scaleh = canvas.height / canvash;

        for (var i = 0; i < cordenadas_X.length; i += 1) {
            var x = parseInt(cordenadas_X[i]);
            var y = parseInt(cordenadas_Y[i]);
    
            if (i == 0) {
                context.moveTo((x - offset_left) * scalew, (y - offset_top) * scalew);
            } else {
                context.lineTo((x - offset_left) * scalew, (y - offset_top) * scalew);
            }
        }
    }

    context.stroke();
    context.fill();
    context.closePath();
}